# GEHMA
Sistema Registro Básico de Asistencia; implementando un CRUD para un docente de una institución educativa cuya población atendida son 25 estudiantes correspondientes al curso de programación.
